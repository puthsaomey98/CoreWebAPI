﻿namespace DotNet8WebAPI.Model
{
    public class AppSettings
    {
        public string Secret { get; set; } = string.Empty;
    }
}
